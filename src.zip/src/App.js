import React from 'react'
import Jobs from './Compnents/Jobs/JobsPage/Jobs';
import { BrowserRouter as Router } from 'react-router-dom';
import { Route } from 'react-router';
import { Switch } from 'react-router';
import { Detail } from './Compnents/Jobs/JobsDetail/Detail';
function App() {
  return (
   <div className="backgroundColor">
     <Router>
       <Switch>
         <Route path="/jobDetails">
           <Detail/>
         </Route>
         <Route path="/">
           <Jobs/>
         </Route>
       </Switch>
     </Router>
   </div>
  );
}

export default App;
