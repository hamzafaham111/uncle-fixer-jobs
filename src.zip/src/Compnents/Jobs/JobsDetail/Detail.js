import React from 'react'
import { Container } from '@material-ui/core'
import { Typography } from '@material-ui/core'
import { Grid } from '@material-ui/core'
import { Button } from '@material-ui/core'
import ApartmentIcon from '@material-ui/icons/Apartment';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import FixerImage from './Assets/fixerLogo.jpeg';
import useStyle from './DetailsStyle'
import {FaGooglePlusG} from 'react-icons/fa';
import {RiBehanceFill} from 'react-icons/ri';
import FacebookIcon from '@material-ui/icons/Facebook';
import TwitterIcon from '@material-ui/icons/Twitter';
import InstagramIcon from '@material-ui/icons/Instagram';
import LinkedInIcon from '@material-ui/icons/LinkedIn';

export const Detail = () => {
    const classes = useStyle();
    return (
        <div>
            <Container>
                <div className={classes.detailWidth}>
                <Grid container>
                    <Grid item xs={12} md={8} >
                        <div className={classes.DetailLeftSide}>
                            <Typography variant="h5">
                            Full Stack Laravel Developer
                            </Typography>
                            <div className={classes.downHeaderDetails}>
                            <Typography className={classes.themeColor}>
                                <ApartmentIcon className={classes.headerIcon}/> 
                                <span>Uncle Fixer</span>
                            </Typography>
                            <Typography className={classes.location}>
                                <LocationOnIcon className={classes.headerIcon}/> Lahore
                            </Typography>
                            </div>
                            <Typography className={classes.detailPageDiscription}>
                            React Router is a collection of navigational components that compose declaratively with your application. 
                            Whether you want to have bookmarkable URLs..
                            </Typography>
                            <Typography className={classes.textBold}>
                                Responsibilities and Duties: 
                            </Typography>
                            <Typography className={classes.detailParagraph} align="justify">
                            Components are the heart of React's powerful, declarative programming model. React Router is a collection of navigational components that compose declaratively with your application. Whether you want to have bookmarkable URLs for your web app or a 
                            composable way to navigate in React Native, React Router works wherever React is rendering--so take your pick!
                            Components are the heart of React's powerful, declarative programming model. React Router is a collection of navigational components that compose declaratively with your application. Whether you want to have bookmarkable URLs for your web 
                            app or a composable way to navigate in React Native, React Router works wherever React is rendering--so take your pick!
                            Components are the heart of React's powerful, declarative programming model. React Router is a collection of navigational components that compose declaratively with your application. Whether you want to have bookmarkable URLs for your web app or a 
                            composable way to navigate in React Native, React Router works wherever React is rendering--so take your pick!
                            </Typography>
                            <div className={classes.skills}>
                                <Typography className={classes.textBold}>Skills</Typography>
                                <div className={classes.skillTypes}>
                                    <span className={classes.unitSkill}>Axios</span>
                                    <span className={classes.unitSkill}>Redux</span>
                                    <span className={classes.unitSkill}>Redux-Persist</span>
                                    <span className={classes.unitSkill}>Redux-Thunk</span>
                                    <span className={classes.unitSkill}>OOP</span>
                                    <span className={classes.unitSkill}>Javascript</span>
                                    <span className={classes.unitSkill}>AsyncStorage</span>
                                    <span className={classes.unitSkill}>Axios</span>
                                    <span className={classes.unitSkill}>Redux</span>
                                    <span className={classes.unitSkill}>Redux-Persist</span>
                                    <span className={classes.unitSkill}>Redux-Thunk</span>
                                    <span className={classes.unitSkill}>OOP</span>
                                    <span className={classes.unitSkill}>Javascript</span>
                                </div>
                            </div>
                            <div className={classes.requirements}>
                                <h2>Requirements:</h2>
                               <ul className={classes.tableStyle}>
                                   <li><span className={classes.requirementPoint}>Job ShiFt:</span> Morning</li>
                                   <li><span className={classes.requirementPoint}>Job Type:</span> Full Time</li>
                                   <li><span className={classes.requirementPoint}>Gender:</span> No PPreference</li>
                                   <li><span className={classes.requirementPoint}>Experience</span>2 Years</li>
                                   <li><span className={classes.requirementPoint}>Vacancy:</span> 1</li>
                                   <li><span className={classes.requirementPoint}>Linguage:</span>English, Urdu</li>
                                   <li><span className={classes.requirementPoint}>Apply before:</span> 21th may 2021</li>
                               </ul>
                            </div>
                        </div>
                    </Grid>
                    <Grid item xs = {12} md={4} >
                        <div className={classes.detailRightSide}>
                          
                            <span className={classes.morning}>Morning</span>
                            <div className={classes.fixerLogo}>
                            <img src = {FixerImage} className={classes.jobDetailImage} alt="Uncle Fixer"/>
                            </div>
                            <Typography variant="h6" className={classes.rightSideHeading} align="center">
                            Full Stack Laravel Developer
                            </Typography>
                            <div className={classes.skills}>
                                <Typography className={classes.textBold}>Skills</Typography>
                                <div className={classes.skillTypes}>
                                    <span className={classes.unitSkill}>Axios</span>
                                    <span className={classes.unitSkill}>Redux</span>
                                    <span className={classes.unitSkill}>Redux-Persist</span>
                                    <span className={classes.unitSkill}>Redux-Thunk</span>
                                    <span className={classes.unitSkill}>OOP</span>
                                    <span className={classes.unitSkill}>Javascript</span>
                                    <span className={classes.unitSkill}>AsyncStorage</span>
                                    <span className={classes.unitSkill}>Axios</span>
                                    <span className={classes.unitSkill}>Redux</span>
                                    <span className={classes.unitSkill}>Redux-Persist</span>
                                    <span className={classes.unitSkill}>Redux-Thunk</span>
                                    <span className={classes.unitSkill}>OOP</span>
                                    <span className={classes.unitSkill}>Javascript</span>
                                </div>
                            </div>
                            <div className={classes.rightSideBtnDiv}>
                                <Button color="primary" variant="contained" className={classes.rightSideBtn}>Appy Now</Button>
                            </div>
                        </div>
                        <div className = {classes.detailRightBottom}>
                            <Typography variant="h7">
                                Shre This Job
                            </Typography>
                            <hr className={classes.hr}/>
                            <Grid container>
                            <Grid xs={4} ><div className={classes.mediaBlock}><FacebookIcon/></div></Grid>
                            <Grid xs={4} ><div className={classes.mediaBlock}><TwitterIcon/></div></Grid>
                            <Grid xs={4} ><div className={classes.mediaBlock}><FaGooglePlusG/></div></Grid>
                            <Grid xs={4} ><div className={classes.mediaBlock}><InstagramIcon/></div></Grid>
                            <Grid xs={4} ><div className={classes.mediaBlock}><LinkedInIcon/></div></Grid>
                            <Grid xs={4} ><div className={classes.mediaBlock}><RiBehanceFill/></div></Grid>
                            </Grid>
                        </div>
                    </Grid>
                </Grid>
                </div>
            </Container>
        </div>
    )
}
