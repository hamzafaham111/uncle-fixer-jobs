import { makeStyles } from "@material-ui/core";

const useStyle = makeStyles({
    detailWidth:{
        width:"80vw",
        margin:"auto",
    },
    DetailLeftSide:{
        background: "White",
        margin:"10px",
        padding:"20px",
    },
    downHeaderDetails:{
        display:"flex",
        flexDirection:"row",
        marginTop:"5px",
    },
    headerIcon:{
        fontSize:"20px",
    },
    themeColor:{
        color:"#1faf05",
        marginRight:"13px",
        display:"flex",
    },
    location:{
        display:"flex",
        color:"gray",
    },
    detailPageDiscription:{
        fontSize:"15px",
        marginTop:"20px",
        marginBottom:"20px",
    },
    textBold:{
        fontWeight:"bold",
    },
    detailParagraph:{
     marginTop:"10px",   
    },
    unitSkill:{
       
        border:"solid gray 1px",
        borderRadius:"33px",
        fontSize: "14px",
        padding:"8px 22px",
        margin:"5px 2px",
        color:"gray",
        "&:hover":{
            backgroundColor:"#1faf05",
            color:"white",
            transition:"0.4s",
            cursor:"pointer",
        }

    },
    skills:{
     marginTop:"20px",
    },
    skillTypes:{
        display:"flex",
        flexWrap:"wrap",
    },
    detailRightSide:{
        background: "White",
        margin:"10px",
        padding:"15px",
    },
    morning:{
        backgroundColor:"#1faf05",
        padding:"10px 20px 10px 20px",
        color:"white",
        borderRadius:"20px",
        fontSize:"20px",
    },
    jobDetailImage:{
        width:"100%",
        height:"100%",
        borderRadius:"100px",
       
    },
    fixerLogo:{
        width:"150px",
        height:"150px",
        margin:"auto",
        marginTop:"25px",
        borderRadius:"100px",
        boxShadow: "rgba(0, 0, 0, 0.20) 0px 5px 15px",
    },
    rightSideHeading:{
        marginTop:"20px",
    },
    rightSideBtnDiv:{
        marginTop:"20px",
    },
    rightSideBtn:{
        width:"100%",
        color:"white",
    },
    requirements:{
        marginTop:"20px",
    },
    tableStyle:{
        listStyle:"none",
    },
    requirementPoint:{
        marginRight:"25px",
        textAlign:"justify",
    },
    detailRightBottom:{
        background: "White",
        margin:"10px",
        padding:"15px",

    },
    hr:{
        marginTop:"20px",
        marginBottom:"20px",
        opacity:"30%",
    },
    mediaBlock:{
        backgroundColor:"#DBDBDB",
        margin:"10px",
        padding:"40px",
    }
    
})
export default useStyle;