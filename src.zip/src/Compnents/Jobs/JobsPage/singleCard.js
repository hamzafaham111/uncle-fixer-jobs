import React from 'react'
import { Container } from '@material-ui/core'
import { Grid } from '@material-ui/core'
import { Link } from 'react-router-dom'
import { Router } from 'react-router'
import { Typography } from '@material-ui/core'
import useStyle from './JobsStyle'
import { Button } from '@material-ui/core'
export const SingleCard = () => {
    const classes = useStyle();
    return (
        <>
            <Container>
                <Link to="/jobDetails" className={classes.link}>
                <div className={classes.card}>
                    <Grid container >
                        <Grid item xs={12} md={9} className={classes.cardContent}>
                        <Typography variant="h5" className={classes.jobHeading}>
                        Full stack Laravel Developer
                    </Typography>
                    <Typography>
                        <Typography className={classes.jobDescription} align="justify">
                            we are looking for a full stack laravel developer having three years of fulltime experience and handon on datastracture
                            We will provide you all the faculties you needed
                        </Typography>
                        <Typography>
                            <a href = "#" className={classes.ReadMoreLink}>Read More</a>          
                        </Typography>
                        <Typography className={classes.vacancyNumber}>
                            Vacancy : 2
                        </Typography>
                        <Typography>
                            Last Date : May 31st 2021
                        </Typography>
                    </Typography>
                        </Grid>
                        <Grid item xs={12} md={3} className={classes.cardButton}>
                        <Button className={classes.btnStyle} variant="contained">Apply Now</Button>
                        </Grid>
                    </Grid>
                </div>
                </Link>
            </Container>
        </>
    )
}
