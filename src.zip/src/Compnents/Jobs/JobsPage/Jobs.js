import React from 'react';
import { SingleCard } from './singleCard';
import './App.css'
import { createMuiTheme } from '@material-ui/core';
import { ThemeProvider } from '@material-ui/styles';
import { Typography } from '@material-ui/core';
import useStyle from './JobsStyle';
const theme=createMuiTheme({
    palette:{
        primary:{
            main:"#1faf05",
        }
    },
    
})
const Jobs = () =>{
    const classes = useStyle();
    return(
    <>
    <ThemeProvider theme={theme}>
    <div className="backgroundColor">
        <Typography align="center" className={classes.jobSPageHeading}>
            <span>Careers @ </span><span className={classes.themeColor}>Uncle Fixer</span>
            <div className={classes.headingBottomLine}></div>
        </Typography>
        <SingleCard/>
        <SingleCard/>
        <SingleCard/>
        <SingleCard/>
    </div>
    </ThemeProvider>
    </>
    )
}
export default Jobs;