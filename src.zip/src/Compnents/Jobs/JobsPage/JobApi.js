const Data = [
    {
        heading : "Full Stack Laravel Developer",
        jobDescription : "we are looking for a full stack laravel developer having three years of fulltime experience and handon on datastracture We will provide you all the faculties you needed",
        vacancyNumber : 2,
        lastDate : "20th jun 2019",
    },
]
export default Data;