const Data = [
    {
        jobID:"1",
        heading : "Full Stack Laravel Developer",
        Description : "we are looking for a full stack laravel developer having three years of fulltime experience and handon on datastracture We will provide you all the faculties you needed",
        Number : 2,
        Date : "20th jun 2019",
    },
    {
        jobID:"2",
        heading : "React Native Interenship",
        Description : "we are looking hu hrieh rhugerighu a full stack laravel developer having three years of fulltime experience and handon on datastracture We will provide you all the faculties you needed",
        Number : 1,
        Date : "11th may 2021",
    },
    {
        jobID:"3",
        heading : "Androide developer",
        Description : "we are looking for a full heh ruhrif herf stack laravel developer having three years of fulltime experience and handon on datastracture We will provide you all the faculties you needed",
        Number : 4,
        Date : "20th jun 2019",
    },
    {
        jobID:"4",
        heading : "Full Stack Laravel Developer",
        Description : "we are looking for a full stack laravel developer having three years of fulltime experience and handon on datastracture We will provide you all the faculties you needed",
        Number : 2,
        Date : "20th jun 2019",
    },
    {
        jobID:"1",
        heading : "Full Stack Laravel Developer",
        Description : "we are looking for a full stack laravel developer having three years of fulltime experience and handon on datastracture We will provide you all the faculties you needed",
        Number : 2,
        Date : "20th jun 2019",
    },
    
]
export default Data;